package ru.edu.pr03;

public enum ApprovalRoute {
    STANDARD,
    FAST_TRACK,
    FINANCE_REVIEW,
    DIRECTOR_REVIEW,
    SECURITY_REVIEW
}
